
numero = int(input("Ingrese un número entero: "))
contador = 0
while numero > 0:
    numero = numero // 10
    contador += 1
print(f"El número tiene {contador} dígitos")
