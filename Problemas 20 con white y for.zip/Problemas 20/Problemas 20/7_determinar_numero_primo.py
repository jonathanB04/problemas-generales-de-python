
numero = int(input("Ingrese un número entero positivo: "))
if numero > 1:
    for i in range(2, int(numero/2) + 1):
        if (numero % i) == 0:
            print(f"{numero} no es un número primo")
            break
    else:
        print(f"{numero} es un número primo")
else:
    print(f"{num} no es un número primo")
