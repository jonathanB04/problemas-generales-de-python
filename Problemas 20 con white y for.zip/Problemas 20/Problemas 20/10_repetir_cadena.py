
cadena = int (input("Ingrese una cadena de texto: "))
numero = int(input("Ingrese un número entero positivo: "))
for _ in range(numero):
    print(cadena)
