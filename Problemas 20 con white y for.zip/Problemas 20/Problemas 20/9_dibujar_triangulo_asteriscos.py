altura = int(input("Ingrese la altura del triángulo: "))
for i in range(1, altura + 1):
    print("*" * i)
