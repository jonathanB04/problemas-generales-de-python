numero = int(input("Ingrese un número entero positivo: "))
while numero < 0:
    print("Número inválido. Inténtelo de nuevo.")
    numero = int(input("Ingrese un número entero positivo: "))
print(f"El número ingresado es: {numero}")
