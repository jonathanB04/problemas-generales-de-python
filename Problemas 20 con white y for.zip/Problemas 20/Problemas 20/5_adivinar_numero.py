import random
numero_secreto = random.randint(1, 10)
intento = None
while intento != numero_secreto:
    intento = int(input("Adivina el número (entre 1 y 10): "))
    if intento < numero_secreto:
        print("Mayor")
    elif intento > numero_secreto:
        print("Menor")
print("¡Adivinaste!")
