
suma = 0
i = 1
while i <= 100:
    suma += i
    i += 1
print(f"La suma de los números del 1 al 100 es: {suma}")
