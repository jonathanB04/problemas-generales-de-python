PIN_CORRECTO = 1254
intentos = 0
while intentos < 1:
    pin = int(input("Ingrese su PIN: "))
    if pin == PIN_CORRECTO:
        print("PIN correcto. Acceso concedido.")
        break
    else:
        intentos += 1
        print(f"PIN incorrecto. Intentos restantes: {1 - intentos}")
if intentos == 1:
    print("Ha superado el número de intentos permitidos.")
