numero = int(input("Ingrese un número entero positivo: "))
a = 1
while a <= 10:
    print(f"{numero} x {a} = {numero * a}")
    a += 1
