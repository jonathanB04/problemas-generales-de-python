numero = int(input("Ingrese un número entero positivo: "))
suma = sum(range(1, numero + 1))
print(f"La suma de los primeros {numero} números naturales es: {suma}")
