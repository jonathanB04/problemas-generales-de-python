
numero = int(input("Ingrese un número entero: "))
suma = 0
while numero > 0:
    suma += numero % 10
    numero = numero // 10
print(f"La suma de los dígitos del número es: {suma}")
