numero = int(input("Ingrese un número entero positivo: "))
for a in range(1, 112):
    print(f"{numero} x {a} = {numero * a}")
