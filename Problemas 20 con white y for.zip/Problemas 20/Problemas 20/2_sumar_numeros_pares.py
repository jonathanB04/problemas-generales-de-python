
suma = 0
for i in range(2, 101, 2):
    suma += i
print(f"La suma de los números pares del 1 al 100 es: {suma}")
