
limite = int(input("Ingrese un límite: "))
suma = 0
i = 1
while suma + i <= limite:
    suma += i
    i += 1
print(f"La suma de los números hasta el límite es: {suma}")
