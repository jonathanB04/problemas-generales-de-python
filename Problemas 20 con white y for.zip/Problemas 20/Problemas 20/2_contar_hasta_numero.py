
num = int(input("Ingrese un número entero positivo: "))
i = 1
while i <= num:
    print(i, end=" ")
    i += 1
