cadena = input("Ingrese una cadena de texto: ")
vocales = "aeiouAEIOU"
contador = 0
for letra  in cadena:
    if letra in vocales:
        contador += 1
print(f"La cantidad de vocales en la cadena es: {contador}")
