
for a in range(10, 0, -1):
    print(a, end=" ")
