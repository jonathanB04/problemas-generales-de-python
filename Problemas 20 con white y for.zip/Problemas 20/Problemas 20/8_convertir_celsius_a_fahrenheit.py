inicio = int(input("Ingrese el rango de temperaturas Celsius : "))
for c in range(inicio + 1):
    f = (c * 9/5) + 32
    print(f"{c}°C = {f}°F")
